@Echo off

xip.exe -e "%1"

pause