:: Rocky5 2024
@echo off
Mode con:cols=70 lines=11 & Color 0B
setlocal enabledelayedexpansion
title v1.3 - Make Skin.xip for "%~n1"

if not exist "Settings.ini" (
	echo [FTP]
	echo enable=false
	echo server=0.0.0.0
	echo username=xbox
	echo password=xbox
)>>"Settings.ini"

For /f "tokens=2,* delims==" %%a in ('findstr /b /i /l "enable" "Settings.ini"') do Set "ftpenabled=%%a"
For /f "tokens=2,* delims==" %%a in ('findstr /b /i /l "server" "Settings.ini"') do Set "server=%%a"
For /f "tokens=2,* delims==" %%a in ('findstr /b /i /l "username" "Settings.ini"') do Set "username=%%a"
For /f "tokens=2,* delims==" %%a in ('findstr /b /i /l "password" "Settings.ini"') do Set "password=%%a"

if "%~n1"=="" (
	echo. & echo. & echo. & echo.
	echo  Drag your folder containing textures onto this bat file.
	echo. & echo. & echo. & echo.
	timeout /t 10
	exit
)

(
	rmdir /q /s "tools\tmp" >nul 2>&1
	XCopy /s /e /i /h /r /y "%~n1\" "tools\tmp\"
	XCopy /s /e /i /h /r /y "tools\xip files\" "tools\tmp\"
	Copy /y "tools\bundler.exe" "tools\tmp\"
	Copy /y "tools\xip.exe" "tools\tmp\"
) > Nul

cd "tools\tmp"

echo.
echo.
echo.
echo  Converting images to xbx:
for /f "tokens=*" %%a in ('dir /b "*.bmp"') do (
	set "name=%%a"
	set "namenoext=%%~na"
	set dtxver=DXT1
	if "!namenoext!"=="AudioPlayerBG" (
		set width=1024
		set height=512
	) else if "!namenoext!"=="background" (
		set width=1024
		set height=512
	) else if "!namenoext!"=="button" (
		set width=256
		set height=32
	) else if "!namenoext!"=="cellwall" (
		set width=256
		set height=256
	) else if "!namenoext!"=="dvd_button" (
		set width=256
		set height=256
	) else if "!namenoext!"=="DVD_paneltex" (
		set width=1024
		set height=64
	) else if "!namenoext!"=="dvdstop" (
		set width=1024
		set height=512
	) else if "!namenoext!"=="dvdstopw" (
		set width=1024
		set height=512
	) else if "!namenoext!"=="footer" (
		set width=512
		set height=64
	) else if "!namenoext!"=="GameHilite_01" (
		set width=512
		set height=64
	) else if "!namenoext!"=="harddrivebg" (
		set width=256
		set height=256
	) else if "!namenoext!"=="highlight" (
		set width=256
		set height=32
	) else if "!namenoext!"=="Live_header" (
		set width=1024
		set height=128
	) else if "!namenoext!"=="LiveChrome" (
		set width=256
		set height=256
	) else if "!namenoext!"=="outline" (
		set width=512
		set height=64
	) else if "!namenoext!"=="Pulse1" (
		set width=512
		set height=16
	) else if "!namenoext!"=="xbox4" (
		set width=256
		set height=256
	) else if "!namenoext!"=="xboxlogo" (
		set width=512
		set height=512
	) else if "!namenoext!"=="xboxlogo64" (
		set width=64
		set height=64
	) else if "!namenoext!"=="xboxlogow" (
		set width=1024
		set height=512
	) else (
		set width=128
		set height=128
	)
	call :rdf_file
	bundler.exe "!namenoext!.rdf" -o "!namenoext!.xbx"
) >nul

dir /b "*.tga" >nul 2>&1
if not errorlevel 1 (
    for /f "tokens=*" %%a in ('dir /b "*.tga"') do (
        set "name=%%a"
        set "namenoext=%%~na"
		set dtxver=DXT3
        if "!namenoext!"=="cellwall" (
			set width=256
			set height=256
		) else if "!namenoext!"=="dvd_button" (
			set width=256
			set height=256
		) else if "!namenoext!"=="DVD_paneltex" (
			set width=1024
			set height=64
		) else if "!namenoext!"=="outline" (
			set width=512
			set height=64
		) else if "!namenoext!"=="xbox4" (
			set width=256
			set height=256
			set dtxver=DXT5
		) else (
			set width=128
			set height=128
		)
        call :rdf_file
        bundler.exe "!namenoext!.rdf" -o "!namenoext!.xbx"
    ) >nul 2>nul
)

REM xip.exe by BigJx
xip.exe -m -c default.xip *.xm *.xbx *.xap >nul

echo  skin.xip created

cd ..\..\

ren "tools\tmp\default.xip" "skin.xip" > Nul

if not "!ftpenabled!"=="true" (
	echo  Done.
	echo. & echo.
) else (
	set "ftppath=C:\xboxdashdata.185ead00\"
	echo  FTP'ing skin.xip to:
	echo   - !ftppath!
	set retrys=5
	set delay=5
	:retry
		echo open !server!>tools\ftp.tmp
		echo !username!>>tools\ftp.tmp
		echo !password!>>tools\ftp.tmp
		echo binary>>tools\ftp.tmp
		echo quote pasv>>tools\ftp.tmp
		echo cd !ftppath!>>tools\ftp.tmp
		echo put tools\tmp\skin.xip>>tools\ftp.tmp
		echo bye>>tools\ftp.tmp

	(
		ftp -s:tools\ftp.tmp >tools\ftp.log
	) >nul 2>&1
	
	findstr /C:"Connected to" tools\ftp.log >nul
	if !ERRORLEVEL! neq 0 (
		set /a retrys-=1
		if !retrys! gtr 0 (
			cls
			echo. & echo. & echo.
			echo  Failed, retrying in !delay! seconds...
			timeout /t !delay! >nul
			del /q tools\ftp.log
			goto retry
		) else (
			echo. & echo. & echo.
			echo  Failed after multiple attempts, aborting.
		)
	) else (
		if !retrys! lss 5 (
			cls
			echo. & echo. & echo.
			echo  Reconnected, FTP'ing skin.xip to:
			echo   - !ftppath!
		)
		echo  Done.
	)
	del /q tools\ftp.tmp >nul
	del /q tools\ftp.log >nul
)

(
	if exist "%~n1.xip" del /q "%~n1.xip"
	move /y "tools\tmp\skin.xip" "%~n1.xip"
	rmdir /q /s "tools\tmp"
) > Nul

:end
	timeout /t 3 >nul
	exit
	
:rdf_file
	(
	echo Texture !namenoext!
	echo {
	echo    Source !name!
	echo    Format D3DFMT_!dtxver!
	echo    Width !width!
	echo    Height !height!
	echo }
	)>!namenoext!.rdf
	goto :eof