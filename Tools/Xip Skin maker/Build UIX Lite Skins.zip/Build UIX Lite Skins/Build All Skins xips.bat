:: Rocky5 2024
@echo off
Mode con:cols=70 lines=11 & Color 0B
setlocal enabledelayedexpansion
title v1.3 - Make All Skin.xips

:start
	echo.
	echo  Converting images to xbx:

	for /f "Tokens=*" %%f in ('dir /b /ad-h-l "*.*"') do (

		(
			rmdir /q /s "tools\tmp" >nul 2>&1
			XCopy /s /e /i /h /r /y "%%f\" "tools\tmp\"
			XCopy /s /e /i /h /r /y "tools\xip files\" "tools\tmp\"
			Copy /y "tools\bundler.exe" "tools\tmp\"
			Copy /y "tools\xip.exe" "tools\tmp\"
		) > Nul

		cd "tools\tmp"
		
		for /f "tokens=*" %%a in ('dir /b "*.bmp"') do (
			set "name=%%a"
			set "namenoext=%%~na"
			set dtxver=DXT1
			if "!namenoext!"=="AudioPlayerBG" (
				set width=1024
				set height=512
			) else if "!namenoext!"=="background" (
				set width=1024
				set height=512
			) else if "!namenoext!"=="button" (
				set width=256
				set height=32
			) else if "!namenoext!"=="cellwall" (
				set width=256
				set height=256
			) else if "!namenoext!"=="dvd_button" (
				set width=256
				set height=256
			) else if "!namenoext!"=="DVD_paneltex" (
				set width=1024
				set height=64
			) else if "!namenoext!"=="dvdstop" (
				set width=1024
				set height=512
			) else if "!namenoext!"=="dvdstopw" (
				set width=1024
				set height=512
			) else if "!namenoext!"=="footer" (
				set width=512
				set height=64
			) else if "!namenoext!"=="GameHilite_01" (
				set width=512
				set height=64
			) else if "!namenoext!"=="harddrivebg" (
				set width=256
				set height=256
			) else if "!namenoext!"=="highlight" (
				set width=256
				set height=32
			) else if "!namenoext!"=="Live_header" (
				set width=1024
				set height=128
			) else if "!namenoext!"=="LiveChrome" (
				set width=256
				set height=256
			) else if "!namenoext!"=="outline" (
				set width=512
				set height=64
			) else if "!namenoext!"=="Pulse1" (
				set width=512
				set height=16
			) else if "!namenoext!"=="xbox4" (
				set width=256
				set height=256
			) else if "!namenoext!"=="xboxlogo" (
				set width=512
				set height=512
			) else if "!namenoext!"=="xboxlogo64" (
				set width=64
				set height=64
			) else if "!namenoext!"=="xboxlogow" (
				set width=1024
				set height=512
			) else (
				set width=128
				set height=128
			)
			call :rdf_file
			bundler.exe "!namenoext!.rdf" -o "!namenoext!.xbx"
		) >nul

		dir /b "*.tga" >nul 2>&1
		if not errorlevel 1 (
			for /f "tokens=*" %%a in ('dir /b "*.tga"') do (
				set "name=%%a"
				set "namenoext=%%~na"
				set dtxver=DXT3
				if "!namenoext!"=="cellwall" (
					set width=256
					set height=256
				) else if "!namenoext!"=="dvd_button" (
					set width=256
					set height=256
				) else if "!namenoext!"=="DVD_paneltex" (
					set width=1024
					set height=64
				) else if "!namenoext!"=="outline" (
					set width=512
					set height=64
				) else if "!namenoext!"=="xbox4" (
					set width=256
					set height=256
					set dtxver=DXT5
				) else (
					set width=128
					set height=128
				)
				call :rdf_file
				bundler.exe "!namenoext!.rdf" -o "!namenoext!.xbx"
			) >nul 2>nul
		)

		REM xip.exe by BigJx
		xip.exe -m -c default.xip *.xm *.xbx *.xap >nul

		cd ..\..\
		
		if exist "%%f.xip" del /q "%%f.xip"
		(
			move /y "tools\tmp\default.xip" "%%f.xip"
			rmdir /q /s "tools\tmp"
		) > Nul

		echo   - %%f.xip created
	)

:end
	echo  Done.
	timeout /t 3 >nul
	exit
	
:rdf_file
	(
	echo Texture !namenoext!
	echo {
	echo    Source !name!
	echo    Format D3DFMT_!dtxver!
	echo    Width !width!
	echo    Height !height!
	echo }
	)>!namenoext!.rdf
	goto :eof